const newfunction = function() {
  const test = 'oh hello';
  return test;
}

let var1 = 'hello';
const x = document.getElementById('test');

if(!event.ctrlKey && !top.BLACKICEcoder.cmdKey) { 
  top.BLACKICEcoder.openCloseDir(this,true); 
  if (/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)) {
    top.BLACKICEcoder.openFile()
  }
}

this.BLACKICEcoder = function() {
 console.log('hello');
}
