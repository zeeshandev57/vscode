<?php
if (!isset($_SESSION['loggedIn'])) {
	die('Sorry, not logged in.');
}
?>
<!--
Purpose:	This file is run when ICEcoder has loaded
Langs:		Anything - PHP, JS etc
Example:
//-->
<script>
// top.ICEcoder.openFile('/index.html');
// alert('Thanks for using ICEcoder');
</script>